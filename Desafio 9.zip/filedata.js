const catalogo = [{
    "id": "1",
    "nombreProducto": "Blend matero",
    "ingProducto": "Cedron - Manzanilla - Cáscaras de naranja",
    "beneficiosProducto": "Mejora la digestión - Desinflama zona estomacal - Regulariza el chakra",
}, {
    "id": "2",
    "nombreProducto": "Ramillete sahumador de manzanilla",
    "ingProducto": "Manzanilla secada hecha ramilletes",
    "beneficiosProducto": "Armoniza ambientes - Prosperidad del hogar - Repele malas energías",
}, {
    "id": "3",
    "nombreProducto": "Blend de rosas (base de te rojo)",
    "ingProducto": "Salvia blanca - Pétalos de Rosa - Chocolate",
    "beneficiosProducto": "Amor propio - Alineamiento del chakra del corazon - Armonia",
}];